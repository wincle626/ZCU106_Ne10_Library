Ne10 Library
=============
See http://projectne10.github.com/Ne10/

Build
=====
See CMakeBuilding.txt file in the "doc" folder, CMakeBuilding.txt also includes doc for android support.

documentation
=============
Run the command "doxygen doxygen.cfg" under ./doc/doxygen.
Then the detailed documentations (.html) will be placed in ./doc/doxygen/documentation.
You could open the "index.html" to start.

Code formatter
==============
See Formatter.txt file in the "doc" folder

